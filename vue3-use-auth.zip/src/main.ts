import { createApp } from 'vue'

// @ts-expect-error TEst
import App from './App'

createApp(App).mount('#app')
